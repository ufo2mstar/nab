all_samples = Dir.glob('sample*.rb')
# puts __FILE__
all_samples.each do |file|
  # next if file == __FILE__
  puts "running #{file}"
  `ruby #{file}`
end